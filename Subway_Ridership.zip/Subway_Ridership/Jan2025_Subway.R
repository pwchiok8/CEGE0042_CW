getwd()

library(sf) # for geospatial data structuring
library(dplyr) # for data structuring
library(ggplot2) # for map plotting
library(cowplot) # organise plots
library(OpenStreetMap) # for map plotting
library(ggspatial) # for map plotting
library(spdep) # for spatial autocorrelation
library(reshape2) # for heatmap
library(tseries) # for ADT on data stationary
library(forecast) # for ARIMA

library(dplyr) # for data structuring before ANN
library(tidyr) # for data structuring before ANN
library(nnet) # for ANN

library(keras) # for LSTM
library(tensorflow) # for LSTM

jan25 <- st_read("Riderships_Jan2025.shp")
# head(jan25)

### ESDA ###
mean(jan25$ridership) # 100.5701
sd(jan25$ridership) # 385.7191

## bubble map
jan25_station <- jan25 %>%
  group_by(station_co, station__2, longitude, latitude) %>% # group by stations and their location
  summarise(total_ridership = sum(ridership, na.rm = TRUE)) # sum total ridership by station
jan25_station$Ridership_in_thousands <- jan25_station$total_ridership/1000 # simplify numerical values by 1000
head(jan25_station[order(jan25_station$total_ridership, decreasing = TRUE), ], 3) # top 3 stations with highest ridership

# use OSM to plot ridership patterns 
map <- openmap(c(40.775359,-74.025844),c(40.696338,-73.955290),type= 'osm') # bounding box of NYC
map <- openproj(map, projection = "epsg:3857") # assign EPSG:3857 as OSM uses this
subway_routes <- st_read("subway_routes_manhatten.shp") # load subway routes
subway_routes <- st_transform(subway_routes, crs = 3857)
jan25_station$longitude <- st_coordinates(jan25_station)[, 1] # extract longitude from geometry 
jan25_station$latitude <- st_coordinates(jan25_station)[, 2] # extract latitude from geometry
jan25_station[, c("longitude_merc", "latitude_merc")] <- projectMercator(jan25_station$latitude, jan25_station$longitude) # project to Mercator necessary to plot on OSM

autoplot.OpenStreetMap(map) + 
  geom_sf(data = subway_routes, 
          aes(linetype = "Subway Routes"), 
          color = "blue", alpha = 0.8, linewidth = 1.1, inherit.aes = FALSE) +
  geom_point(data = jan25_station, 
             aes(x = longitude_merc, y = latitude_merc, 
                 color = Ridership_in_thousands, 
                 size = Ridership_in_thousands)) +
  scale_color_gradient(low = "#FFD700", high = "#8B0000") + 
  scale_size(range = c(2, 10)) + 
  scale_linetype_manual(name = "Routes", values = c("Subway Routes" = "solid")) +
  labs(title = "Total Subway Ridership in January 2025",
       color = "Total Ridership\n(in thousands)",  
       size = "Total Ridership\n(in thousands)") +  
  annotation_scale(location = "br", width_hint = 0.4) +  
  annotation_north_arrow(location = "tl", which_north = "grid") +  
  theme_minimal() +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    axis.text.x = element_blank(),
    axis.text.y = element_blank(),
    axis.ticks.x = element_blank(),
    axis.ticks.y = element_blank())

## histogram
p1 <- ggplot(jan25, aes(x = ridership)) +
  geom_histogram(bins = 50, color = "white") +
  theme_minimal() +
  labs(title = "Histogram of Hourly Subway Ridership (January 2025)", x = "Ridership", y = "Frequency")

p2 <- ggplot(jan25, aes(x = log(ridership))) +
  geom_histogram(bins = 50, color = "white") +
  theme_minimal() +
  labs(x = "log(Ridership)", y = "Frequency")

plot_grid(p1, p2, nrow = 2) # arrange plots in 2 rows

## total hourly ridership for 2nd week of Jan 2025
# filter 2nd week of Jan
jan25_time <- jan25 %>%
  mutate(datetime = as.POSIXct(datetime, format = "%Y-%m-%d %I:%M:%S %p", tz = "UTC")) %>% # Convert datetime to POSIXct
  filter(datetime >= as.POSIXct("2025-01-06 00:00:00", tz = "UTC") & 
             datetime < as.POSIXct("2025-01-13 00:00:00", tz = "UTC"))  # Filter the 2nd week
  
# aggregate ridership by hour (datetime)
jan25_hourly <- jan25_time %>%
  group_by(datetime) %>% # group the data by hour (datetime)
  summarise(total_ridership = sum(ridership, na.rm = TRUE)) # sum the ridership by hour

jan25_hourly$hour <- format(jan25_hourly$datetime, "%Y-%m-%d %H:00:00") # new column to represent just the hour of the day

ggplot(jan25_hourly, aes(x = as.POSIXct(hour), y = total_ridership)) +
  geom_line() +
  labs(title = "Hourly Ridership for 2nd Week of January 2025",
       x = "Hour",
       y = "Total Ridership") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

## heatmap of ridership for 2nd week of Jan 2025

# aggregate ridership by station (station__2) and hour (datetime)
jan25_hourly_stn <- jan25_time %>%
  group_by(station__2, datetime) %>%  # group the data by station and hour
  summarise(total_ridership = sum(ridership, na.rm = TRUE))  # sum ridership per station per hour

# reshape data series so each row represents a station-hour ridership count
reshape_data_long <- jan25_hourly_stn %>%
  rename(SubwayStation = station__2, TimeStamp = datetime, Ridership = total_ridership) 

# extract timestamps for labelling 
timestamp_ticks <- seq(2, length(unique(reshape_data_long$TimeStamp)), by = 12) # select every 12 hours for labels

# plot heatmap
ggplot(reshape_data_long, aes(x = as.character(TimeStamp), y = factor(SubwayStation), fill = Ridership)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "green", mid = "yellow", high = "red", 
                       midpoint = median(reshape_data_long$Ridership, na.rm = TRUE)) +
  scale_x_discrete(breaks = unique(as.character(reshape_data_long$TimeStamp))[timestamp_ticks]) +
  scale_y_discrete(labels = NULL) + 
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = "Timestamp", y = "Subway Station", title = "Subway Ridership by Station (2nd Week of January 2025)")


## temporal autocorrelation (ACF and PACF)

# create a time series object with hourly data, i.e. 24 hrs a day
jan25_hourly_ttl<- jan25 %>%
  mutate(datetime = as.POSIXct(datetime, format = "%Y-%m-%d %I:%M:%S %p", tz = "UTC")) %>% # converts the datetime column into POSIXct format
  group_by(datetime) %>% # group the data by hour (datetime)
  summarise(total_ridership = sum(ridership, na.rm = TRUE)) # sum the ridership by hour

jan25_ts <- ts(jan25_hourly_ttl$total_ridership, start = c(2024, 1, 1), frequency = 24)

adf.test(jan25_ts) # p = 0.01, yes the data is stationary

# plot ACF and PACF
par(mfrow = c(2,1))
acf(jan25_ts, lag.max = 48, main = "ACF")
pacf(jan25_ts, lag.max = 48, main = "PACF")

# apply seasonal differencing with lag of 24 hours
jan25_ts_diff <- diff(jan25_ts, lag = 24, differences = 1)

# plot S-ACF and S-PACF
par(mfrow = c(2,1))
acf(jan25_ts_diff, lag.max = 48, main = "S-ACF")
pacf(jan25_ts_diff, lag.max = 48, xlab="Lag", ylab="PACF", 
     main="S-PACF")

## spatial autocorrelation
jan25_sf <- st_as_sf(jan25_station, coords = c("longitude", "latitude"), crs = 4326)
unique(jan25_sf$geometry) # 66 unique subway stations

# compute k-nearest neighbors for all 66 unique stations (n-1 nearest neighbours)
morans_values <- sapply(1:65, function(k) {
  W <- nb2mat(knn2nb(knearneigh(jan25_sf, k = k)), style = "W")
  moran.test(jan25_sf$total_ridership, nb2listw(knn2nb(knearneigh(jan25_sf, k = k)), style = "W"))$estimate[1]
})

# plot Moran's I values for different k
par(mfrow = c(1,1))
plot(1:65, morans_values, type = "b", xlab = "Number of Neighbours (k)", ylab = "Moran's I")
which.max(morans_values) # k = 4
max(morans_values) # 0.1731536, k = 4

W1 <- nb2mat(knn2nb(knearneigh(jan25_sf, k = 4)), style = "W")
moran_test <- moran.test(jan25_sf$total_ridership, nb2listw(knn2nb(knearneigh(jan25_sf, k = 4))))
print(moran_test)

## SARIMA

# normalise the ridership data (for future comparison with LTSM and since dataset has high ridership counts and high variance)
normalised_ridership <- (jan25_hourly_ttl$total_ridership - min(jan25_hourly_ttl$total_ridership, na.rm = TRUE)) / 
  (max(jan25_hourly_ttl$total_ridership, na.rm = TRUE) - min(jan25_hourly_ttl$total_ridership, na.rm = TRUE))

training <- ts(normalised_ridership[1:(24*25)], frequency = 24) # 24 hours for first 25 days in Jan, making up ~ 80% of training data
test <- ts(normalised_ridership[(24*25)+1:744], frequency = 24) # test on rest of data (20%)

# custom ARIMA
custom_sarima <- arima(training,order=c(3,0,4),seasonal=list(order=c(2,1,2),period=24)) # ARIMA(3,0,4)(2,1,2)[24] 
summary(custom_sarima)

custom_sarima_forecast <- forecast(custom_sarima, h = 24*6) # test on last 6 days

predict_data <- as.vector(custom_sarima_forecast$mean)
actual_data <- as.vector(normalised_ridership[601:744]) 

# plot actual vs predicted data 
matplot(1:144, cbind(actual_data, predict_data), type="l", xlab="Hours", ylab="Ridership (normalised)", 
        col=c("black", "red"), lty=1:2, main = "Custom S-ARIMA")  # Blue for actual, red for predicted
legend("topright", legend=c("Actual", "Predicted"), col=c("black", "red"), xpd=TRUE, inset=c(0, -0.45), lty=1:2)

# auto ARIMA
auto_sarima <- auto.arima(training, seasonal = TRUE) # ARIMA(2,0,1)(1,1,1)[24]
summary(auto_sarima)

auto_sarima_forecast <- forecast(auto_sarima, h = 24*6) # test on last 6 days

predict_data2 <- as.vector(auto_sarima_forecast$mean)
actual_data2 <- as.vector(normalised_ridership[601:744]) 

# plot actual vs predicted data 
matplot(1:144, cbind(actual_data2, predict_data2), type="l", xlab="Hours", ylab="Ridership (normalised)", 
        col=c("black", "red"), lty=1:2, main = "Auto S-ARIMA")  # Blue for actual, red for predicted
legend("topright", legend=c("Actual", "Predicted"), col=c("black", "red"), xpd=TRUE, inset=c(0, -0.45), lty=1:2)


## FNN & LSTM data pre-processing

jan25_df2 <- as.data.frame(jan25)[, c("datetime", "station__2", "ridership")]
write.csv(jan25_df2, "Riderships_Jan2025.csv", row.names = FALSE) # saving pit stop
jan25_df <- read.csv("Riderships_Jan2025.csv")
head(jan25_df)

jan25_df$datetime <- as.POSIXct(jan25_df$datetime, format="%Y-%m-%d %I:%M:%S %p", tz="UTC") # transform datetime into correct POSIXct format
jan25_agg <- jan25_df %>%
  group_by(datetime, station__2) %>%
  summarise(total_ridership = sum(ridership)) # aggregate ridership by hour and station name

jan25_wide <- jan25_agg %>%
  pivot_wider(id_cols = datetime, names_from = station__2, values_from = total_ridership, values_fill = 0) %>%
  arrange(datetime) # create table to stations as columns and datetime as rows

rownames(jan25_wide) <- jan25_wide$datetime # convert the datetime values to row names
jan25_matrix <- as.matrix(jan25_wide[, -1]) # convert to matrix, remove first column containing datetime

# perform normalisation on entire matrix
jan25_matrix_norm <- jan25_matrix
for (i in 1:ncol(jan25_matrix)) {
  min_val <- min(jan25_matrix[,i], na.rm = TRUE)
  max_val <- max(jan25_matrix[,i], na.rm = TRUE)
  
  jan25_matrix_norm[,i] <- (jan25_matrix[,i] - min_val) / (max_val - min_val)
}

# create X and Y
X_norm <- as.matrix(jan25_matrix_norm)
y_norm <- as.matrix(X_norm[-1,]) # remove first hour

## ANN (FNN)

# conduct grid search to find optimal decay value and size
decay_values <- c(1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7)
sizes <- c(5, 10, 15, 20, 25)

best_model <- NULL
best_rmse <- Inf

# calculate RMSE against different parameter combination
rmse_values <- matrix(NA, length(sizes), length(decay_values))

for (i in seq_along(sizes)) {
  for (j in seq_along(decay_values)) {
    set.seed(1)
    temp.nnet <- nnet(X_norm[1:(24*25), 1:66], 
                      y_norm[1:(24*25), 1, drop = FALSE], 
                      decay = decay_values[j], 
                      linout = TRUE, 
                      size = sizes[i], 
                      MaxNWts = 5000)
    
    temp.pred <- predict(temp.nnet, X_norm[601:743, 1:66])
    
    current_rmse <- sqrt(mean((y_norm[601:743, 1] - temp.pred[, 1])^2))
    rmse_values[i, j] <- current_rmse
    
    if (current_rmse < best_rmse) {
      best_rmse <- current_rmse
      best_model <- list(decay = decay_values[j], size = sizes[i], rmse = best_rmse)
    }
  }
}

print(best_model) # decay = 1e-6, size = 20, rmse = 0.0483

# plot RMSE heatmap
rmse_df <- data.frame(
  size = rep(sizes, length(decay_values)),
  decay = rep(decay_values, each = length(sizes)),
  RMSE = as.vector(rmse_values)
)

ggplot(rmse_df, aes(x = factor(decay), y = factor(size), fill = RMSE)) +
  geom_tile() +
  scale_fill_gradient(low = "green", high = "red") +
  labs(x = "Decay", y = "Network Size")

# FNN training using optimal decay value and size, and split training and test
set.seed(1) 
temp.nnet <- nnet(X_norm[1:(24*25), 1:66], y_norm[1:(24*25), 1:66], decay=1e-6, linout=TRUE, size=20, MaxNWts = 5000)

# predict on last 6 days
temp.pred<-predict(temp.nnet, y_norm[601:743, 1:66])
total_actual <- rowSums(y_norm[601:743, 1:66], na.rm = TRUE)
total_predicted <- rowSums(temp.pred[, 1:66], na.rm = TRUE)

# plot actual vs predicted
par(mfrow = c(1,1))

matplot(cbind(total_actual, total_predicted), 
        ylab = "Ridership (Normalised)", 
        xlab = "Hours", 
        main = "Actual vs. Predicted (FNN)", 
        type = "l", 
        col = c("black", "red"),
        lty = 1:2) 

legend("topright", 
       legend = c("Actual", "Predicted"), 
       col = c("black", "red"),
       lty = 1:2, 
       inset = c(0, -0.45), 
       xpd = TRUE)

# performance metrics
mse <- mean((total_actual - total_predicted)^2)
mae <- mean(abs(total_actual - total_predicted))
rmse <- sqrt(mean((total_actual - total_predicted)^2))

cat("MSE:", mse, "\n")
cat("MAE:", mae, "\n")
cat("RMSE:", rmse, "\n")

## LTSM (RNN)

# install_keras(envname = "r-reticulate") # if needed
use_virtualenv("r-reticulate")

# embed normalised ridership values into 24hr + 1 timesteps
timesteps <- 24
n_stations <- ncol(X_norm)

# create 3D tensor for LSTM input (samples, timesteps, features) since there are multiple features for multiple stations
X_ts <- array(0, dim = c(nrow(X_norm) - timesteps, timesteps, n_stations))
y_ts <- array(0, dim = c(nrow(X_norm) - timesteps, n_stations))

for (i in 1:(nrow(X_norm) - timesteps)) {
  X_ts[i,,] <- X_norm[i:(i + timesteps - 1),]
  y_ts[i,] <- X_norm[i + timesteps,]
}

# train-test split
tr <- ceiling(nrow(X_ts) * 0.8)
X_train <- X_ts[1:tr,,]
y_train <- y_ts[1:tr,]
X_test <- X_ts[(tr+1):dim(X_ts)[1],,]
y_test <- y_ts[(tr+1):dim(y_ts)[1],]

# conduct grid search to find optimal epochs, hidden dims, batch sizes
epochs_list <- c(16, 32, 64)
hidden_dims <- c(8, 16, 32)
batch_sizes <- c(16, 32)

# store results
best_rmse <- Inf
best_params <- list()
results <- data.frame()

# calculate RMSE against different parameter combination
for (epoch in epochs_list) {
  for (hidden_dim in hidden_dims) {
    for (batch_size in batch_sizes) {
      
      # define model with 2 layers
      model <- keras_model_sequential() %>%
        layer_lstm(units = hidden_dim, return_sequences = TRUE, input_shape = c(timesteps, n_stations)) %>%
        layer_lstm(units = hidden_dim) %>%
        layer_dense(units = n_stations)
      
      # compile
      model %>% compile(loss = "mean_squared_error", optimizer = optimizer_adam(learning_rate = 0.01))
      
      # train
      history <- model %>% fit(X_train, y_train, 
                               epochs = epoch, 
                               batch_size = batch_size, 
                               validation_data = list(X_test, y_test), 
                               verbose = 0)
      
      # predict
      y_test_pred <- model %>% predict(X_test)
      total_actual <- rowSums(y_test)
      total_pred <- rowSums(y_test_pred)
      rmse <- sqrt(mean((total_actual - total_pred)^2))
      
      if (rmse < best_rmse) {
        best_rmse <- rmse
        best_params <- list(epoch = epoch, hidden_dim = hidden_dim, batch_size = batch_size, rmse = best_rmse)
      }
      
      results <- rbind(results, data.frame(epoch, hidden_dim, batch_size, RMSE = rmse)) # store results
      
      cat("epoch:", epoch, " hidden_dim:", hidden_dim, " batch_size:", batch_size, " RMSE:", rmse, "\n")
    }
  }
}

print(best_params) # epoch = 64, hidden_dim = 32, batch_size = 16, rmse = 1.027

# plot RMSE heatmap
ggplot(results, aes(x = factor(epoch), y = factor(hidden_dim), fill = RMSE)) +
  geom_tile() +
  scale_fill_gradient(low = "green", high = "red") +
  labs(title = "Epochs and Hidden Dimensions by Batch Sizes 16 and 32", x = "Epochs", y = "Hidden Dimensions", fill = "RMSE") +
  facet_wrap(~batch_size)

# LSTM model parameters based on grid search
hidden_dim <- 32
output_dim <- n_stations # 66 stations
num_epochs <- 64
batch_size <- 16

# define LSTM Model
model <- keras_model_sequential() %>%
  layer_lstm(units = hidden_dim, return_sequences = TRUE, input_shape = c(timesteps, n_stations)) %>%
  layer_lstm(units = hidden_dim) %>%
  layer_dense(units = output_dim)

# compile
model %>% compile(loss = "mean_squared_error", optimizer = optimizer_adam(learning_rate = 0.01))

# train
history <- model %>% fit(X_train, y_train, epochs = num_epochs, batch_size = batch_size, validation_data = list(X_test, y_test))

# make predictions
y_train_pred <- model %>% predict(X_train)
y_test_pred  <- model %>% predict(X_test)

# calculate total ridership
total_actual2 <- rowSums(y_test)
total_predicted2 <- rowSums(y_test_pred)

# plot actual vs predicted ridership
matplot(cbind(total_actual2, total_predicted2), 
        ylab = "Ridership (Normalised)", 
        xlab = "Hours", 
        main = "Actual vs. Predicted (LSTM)", 
        type = "l", 
        col = c("black", "red"),
        lty = 1:2) 

legend("topright", 
       legend = c("Actual", "Predicted"), 
       col = c("black", "red"), 
       lty = c(1, 2), 
       inset = c(0, -0.45), 
       xpd = TRUE)

# performance metrics
mse2 <- mean((total_actual2 - total_predicted2)^2)
mae2 <- mean(abs(total_actual2 - total_predicted2))
rmse2 <- sqrt(mean((total_actual2 - total_predicted2))^2)

cat("MSE:", mse2, "\n")
cat("MAE:", mae2, "\n")
cat("RMSE:", rmse2, "\n")
